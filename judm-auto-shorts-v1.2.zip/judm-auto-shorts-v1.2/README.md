# JUD.M Auto Shorts v1.2

완전 무료 범위를 우선한 JUD.M 게임 숏폼 자동편집/게시 파이프라인입니다.

## 목표 흐름
`Google Drive 00_INBOX` → GitHub Actions → 자동 하이라이트 분석 → 1080×1920 편집 → 플랫폼별 게시 → `02_POSTED`

## 자동편집
- 장면 변화량, 움직임, 오디오 피크를 합산해 12~24초 하이라이트 선정
- 1080×1920 H.264/AAC
- 가로 게임 화면은 전체 HUD를 보존하고 9:16 블러 배경으로 채움
- Do Hyeon + Noto Sans CJK KR
- 초반 훅, 줌 펀치, 후반 CTA
- TikTok 버전에는 게임명/브랜딩 라벨을 넣지 않음

## 자동 실행
- 12:37 / 20:37 Asia/Seoul
- 한 번에 원본 1개
- 플랫폼별 게시 ID를 Drive `appProperties`에 저장해 중복 게시 방지
- 공개 저장소의 60일 무활동 시 schedule 자동중지 문제를 피하려 월 1회 heartbeat commit 수행

## 플랫폼 정책 반영
### YouTube
`videos.insert`는 2020-07-28 이후 생성된 미감사 API 프로젝트에서 업로드 영상이 private로 제한됩니다. 감사 승인 전 `YOUTUBE_ENABLED=false` 유지.

### Instagram
Instagram Login 기반 Professional(Business/Creator) 게시 경로를 사용합니다. `instagram_business_content_publish` 권한이 필요합니다. 공개 video URL이 필요해 Cloudinary Free를 임시 호스팅으로 사용합니다.

### TikTok
일반 Content Posting API는 내부 계정 자동업로더 용도로 적합하지 않고 게시 전 사용자 UX/명시적 동의를 요구합니다. v1.2은 **TikTok API for Business Accounts API v1.3**의 `/business/video/publish/` 경로를 사용합니다. 대상 계정은 TikTok Business Account여야 하며 `TikTok Accounts > Account Post Content > Video Publish` 권한 승인이 필요합니다. 토큰 응답의 `open_id`를 `business_id`로 사용합니다.

## 무료 조건
- GitHub Actions: public 저장소의 standard runner 무료
- FFmpeg/OpenCV: 무료
- Google Drive API: 무료 범위
- Google Fonts: OFL
- Cloudinary Free: 카드 없이 25 credits/30일 rolling window
- 플랫폼 API: API 사용료 없음. 단, 플랫폼 심사/권한 승인이 필요할 수 있음

## 안전장치
게시 승인 전 모든 플랫폼 변수는 `false`로 유지하십시오. 먼저 `preview` 모드로 실제 Drive 영상의 편집 결과를 검수한 뒤 플랫폼별 게시 기능을 켭니다.

## Drive 서비스 계정 주의
개인 `@gmail.com`의 My Drive에서는 서비스 계정이 새 파일을 소유할 수 없으므로, 토큰 상태 파일 `JUDM_AUTO_STATE.json`은 사용자가 `JUDM_MARKETING` 루트에 **한 번만 직접 업로드**합니다. 이후 서비스 계정은 공유된 편집자 권한으로 이 기존 파일을 갱신합니다.
