from __future__ import annotations
import os, requests

def refresh_instagram(token:str)->str:
    r=requests.get('https://graph.instagram.com/refresh_access_token',params={'grant_type':'ig_refresh_token','access_token':token},timeout=30)
    r.raise_for_status(); return r.json()['access_token']

def refresh_tiktok_business(refresh_token:str)->tuple[str,str,str]:
    r=requests.post('https://business-api.tiktok.com/open_api/v1.3/tt_user/oauth2/refresh_token/',headers={'Content-Type':'application/json'},json={
        'client_id': os.environ['TIKTOK_CLIENT_ID'],
        'client_secret': os.environ['TIKTOK_CLIENT_SECRET'],
        'grant_type':'refresh_token',
        'refresh_token': refresh_token,
    },timeout=30)
    r.raise_for_status(); body=r.json()
    if body.get('code') not in (0,'0',None): raise RuntimeError(body)
    d=body['data']; return d['access_token'], d['refresh_token'], d['open_id']
