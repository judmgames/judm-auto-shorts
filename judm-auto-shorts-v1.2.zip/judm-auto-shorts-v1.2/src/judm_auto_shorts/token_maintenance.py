from __future__ import annotations
import json, os, time
from .config import Settings
from .providers.drive import DriveProvider
from .tokens import refresh_instagram

def main():
    s=Settings.load(); drive=DriveProvider(); sib=drive.resolve_siblings(s.inbox_id); state=drive.read_state(sib['root']); out={}
    if os.getenv('INSTAGRAM_ENABLED','false').lower() in {'1','true','yes','on'}:
        last=int(state.get('instagram_refreshed_at') or 0)
        if time.time()-last > 25*86400:
            current=state.get('instagram_access_token') or os.environ['INSTAGRAM_ACCESS_TOKEN']
            state['instagram_access_token']=refresh_instagram(current); state['instagram_refreshed_at']=int(time.time()); out['instagram']='refreshed'
    drive.write_state(sib['root'],state); print(json.dumps(out,ensure_ascii=False))
if __name__=='__main__': main()
