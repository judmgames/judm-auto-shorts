from __future__ import annotations
import json
from pathlib import Path

from .config import Settings
from .providers.drive import DriveProvider
from .metadata import make_metadata
from .editor import auto_edit, probe


def _small(f:dict):
    sd=f.get("shortcutDetails") or {}
    return {
        "id":f.get("id"),"name":f.get("name"),"mimeType":f.get("mimeType"),
        "size":f.get("size"),"parents":f.get("parents"),
        "targetId":sd.get("targetId"),"targetMimeType":sd.get("targetMimeType"),
        "canDownload":(f.get("capabilities") or {}).get("canDownload"),
    }


def main():
    s=Settings.load(); d=DriveProvider()
    print("JUDM_VERSION=2.0.0-final")

    candidates,report=d.candidate_files(s.inbox_id,50)
    # Always print decisive diagnostics in compact form so one run is enough to
    # distinguish code/MIME/shortcut issues from a Drive permission issue.
    compact={
        "service_account":report.get("service_account"),
        "folder_id":report.get("folder_id"),
        "folder":report.get("folder"),
        "folder_error":report.get("folder_error"),
        "about":report.get("about"),
        "direct_children":[_small(x) for x in report.get("direct_children",[])],
        "visible_files":[_small(x) for x in report.get("visible_files",[])],
        "candidate_count":report.get("candidate_count"),
    }
    print("JUDM_DRIVE_REPORT="+json.dumps(compact,ensure_ascii=False))

    if not candidates:
        raise SystemExit(
            "DRIVE_NO_VISIBLE_VIDEO: service account can open 00_INBOX but sees no downloadable file candidates. "
            "This is a Drive permission/content visibility issue, not an editor bug."
        )

    source_dir=Path("out")/"source"; source_dir.mkdir(parents=True,exist_ok=True)
    errors=[]
    for f in candidates:
        raw=source_dir/d.local_name(f)
        try:
            d.download(f,raw)
            p=probe(raw)
            if p.duration<2 or p.width<240 or p.height<240:
                raise RuntimeError(f"not usable video: {p}")
            outputs=auto_edit(raw,Path("out")/"edited",make_metadata(f.get("name") or raw.name))
            print("JUDM_PREVIEW_OK="+json.dumps({
                "source":f.get("name"),"source_id":f.get("id"),"probe":p.__dict__,"outputs":outputs
            },ensure_ascii=False))
            return
        except Exception as e:
            errors.append({"file":_small(f),"error":f"{type(e).__name__}: {e}"})
            try: raw.unlink(missing_ok=True)
            except Exception: pass

    print("JUDM_PREVIEW_ERRORS="+json.dumps(errors,ensure_ascii=False))
    raise SystemExit("DRIVE_FILES_FOUND_BUT_NO_DECODABLE_VIDEO: see JUDM_PREVIEW_ERRORS above")


if __name__=="__main__": main()
