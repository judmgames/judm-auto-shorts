from __future__ import annotations
import time, requests

BASE='https://business-api.tiktok.com/open_api/v1.3'

def _check(r: requests.Response):
    r.raise_for_status(); d=r.json()
    if d.get('code') not in (0, '0', None):
        raise RuntimeError(f"TikTok API error: {d}")
    return d.get('data') or {}

def publish_url(video_url:str, caption:str, token:str, business_id:str)->str:
    body={
        'business_id': business_id,
        'video_url': video_url,
        'post_info': {
            'caption': caption,
            'disable_comment': False,
            'disable_duet': False,
            'disable_stitch': False,
        },
    }
    r=requests.post(f'{BASE}/business/video/publish/',headers={'Access-Token':token,'Content-Type':'application/json'},json=body,timeout=60)
    share_id=_check(r).get('share_id')
    if not share_id:
        raise RuntimeError('TikTok publish returned no share_id')
    for _ in range(60):
        s=requests.get(f'{BASE}/business/publish/status/',headers={'Access-Token':token},params={'business_id':business_id,'publish_id':share_id},timeout=30)
        d=_check(s); status=d.get('status')
        if status=='FAILED':
            raise RuntimeError(f"TikTok publish failed: {d.get('reason')}")
        if status=='PUBLISH_COMPLETE':
            ids=d.get('post_ids') or []
            if ids:
                return str(ids[0])
        time.sleep(5)
    raise TimeoutError(f'TikTok publish still processing: {share_id}')
