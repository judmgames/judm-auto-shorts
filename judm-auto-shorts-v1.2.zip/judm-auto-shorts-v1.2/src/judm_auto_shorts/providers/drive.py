from __future__ import annotations
import io, json, os, re
from pathlib import Path
from typing import Iterable

from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from googleapiclient.http import MediaIoBaseDownload, MediaIoBaseUpload

SCOPES=["https://www.googleapis.com/auth/drive"]
FOLDER_MIME="application/vnd.google-apps.folder"
SHORTCUT_MIME="application/vnd.google-apps.shortcut"
GOOGLE_VIDEO_MIME="application/vnd.google-apps.video"
VIDEO_EXTS={".mp4",".mov",".m4v",".webm",".avi",".mkv",".3gp",".mpeg",".mpg",".ts",".mts",".m2ts"}

FILE_FIELDS=(
    "id,name,mimeType,size,createdTime,modifiedTime,parents,appProperties,resourceKey,"
    "shortcutDetails(targetId,targetMimeType,targetResourceKey),"
    "capabilities(canDownload,canEdit)"
)


def _clean_name(name:str, fallback:str="source.mp4") -> str:
    name=(name or "").replace("\\","_").replace("/","_").strip()
    name=re.sub(r"[\x00-\x1f]","_",name)
    return name or fallback


class DriveProvider:
    def __init__(self):
        raw=os.environ["GOOGLE_SERVICE_ACCOUNT_JSON"]
        info=json.loads(raw)
        self.service_account_email=info.get("client_email","")
        creds=service_account.Credentials.from_service_account_info(info,scopes=SCOPES)
        self.api=build("drive","v3",credentials=creds,cache_discovery=False)

    def about(self):
        try:
            return self.api.about().get(fields="user(emailAddress,displayName),storageQuota(limit,usage)").execute()
        except Exception as e:
            return {"error":f"{type(e).__name__}: {e}"}

    def folder(self, folder_id:str):
        return self.api.files().get(
            fileId=folder_id,
            fields="id,name,mimeType,parents,shared,resourceKey,capabilities(canDownload,canEdit,canListChildren)",
            supportsAllDrives=True,
        ).execute()

    def _files_list(self,q:str,limit:int=200,order_by:str="createdTime"):
        # Explicitly use the service account's user corpus. This is the most reliable
        # way to list My Drive files/folders that have been shared to the account.
        kwargs=dict(
            q=q,
            spaces="drive",
            corpora="user",
            fields=f"nextPageToken,files({FILE_FIELDS})",
            orderBy=order_by,
            pageSize=max(1,min(limit,1000)),
            supportsAllDrives=True,
            includeItemsFromAllDrives=True,
        )
        out=[]; token=None
        while len(out)<limit:
            if token: kwargs["pageToken"]=token
            r=self.api.files().list(**kwargs).execute()
            out.extend(r.get("files",[]))
            token=r.get("nextPageToken")
            if not token: break
        return out[:limit]

    def direct_children(self,folder_id:str,limit:int=200):
        return self._files_list(f"'{folder_id}' in parents and trashed=false",limit)

    def visible_files(self,limit:int=500):
        return self._files_list("trashed=false",limit)

    @staticmethod
    def _is_folder(f:dict)->bool:
        return (f.get("mimeType") or "").lower()==FOLDER_MIME

    @staticmethod
    def _target_info(f:dict)->tuple[str,str,str|None]:
        """Return effective id, MIME, resource key (resolving Drive shortcuts)."""
        mt=(f.get("mimeType") or "").lower()
        if mt==SHORTCUT_MIME:
            sd=f.get("shortcutDetails") or {}
            return sd.get("targetId") or f.get("id"), (sd.get("targetMimeType") or "").lower(), sd.get("targetResourceKey")
        return f.get("id"), mt, f.get("resourceKey")

    @classmethod
    def _looks_video(cls,f:dict)->bool:
        _,mt,_=cls._target_info(f)
        ext=Path(f.get("name") or "").suffix.lower()
        return mt.startswith("video/") or mt==GOOGLE_VIDEO_MIME or ext in VIDEO_EXTS

    def candidate_files(self,folder_id:str,limit:int=50)->tuple[list[dict],dict]:
        """Return candidates + a diagnostic report. Never hides the underlying listing."""
        direct=self.direct_children(folder_id,max(100,limit))
        visible=self.visible_files(500)

        # 1) direct children that look like videos
        picked=[]; seen=set()
        for f in direct:
            if self._is_folder(f): continue
            if self._looks_video(f) and f.get("id") not in seen:
                picked.append(f); seen.add(f.get("id"))

        # 2) visible videos whose parent relation may have been omitted by Drive API
        if len(picked)<limit:
            for f in visible:
                if self._is_folder(f): continue
                if self._looks_video(f) and f.get("id") not in seen:
                    picked.append(f); seen.add(f.get("id"))
                    if len(picked)>=limit: break

        # 3) final generic fallback: attempt any direct non-folder, then visible non-folder.
        # ffprobe in preview/pipeline will reject non-video files safely.
        if not picked:
            for pool in (direct,visible):
                for f in pool:
                    if self._is_folder(f) or f.get("id") in seen: continue
                    picked.append(f); seen.add(f.get("id"))
                    if len(picked)>=limit: break
                if picked: break

        picked.sort(key=lambda x:x.get("createdTime", ""))
        report={
            "service_account":self.service_account_email,
            "folder_id":folder_id,
            "folder":None,
            "about":self.about(),
            "direct_children":direct,
            "visible_files":visible[:200],
            "candidate_count":len(picked),
        }
        try: report["folder"]=self.folder(folder_id)
        except Exception as e: report["folder_error"]=f"{type(e).__name__}: {e}"
        return picked[:limit], report

    def _find_visible_folder(self,name:str):
        safe=name.replace("'", "\\'")
        q=f"trashed=false and mimeType='{FOLDER_MIME}' and name='{safe}'"
        r=self._files_list(q,100)
        if not r:
            raise RuntimeError(f"Shared folder not visible to service account: {name}")
        return r[0]

    def resolve_siblings(self,inbox_id:str):
        inbox=self.folder(inbox_id); parents=inbox.get("parents") or []
        if parents:
            root=parents[0]
            def find(name):
                safe=name.replace("'", "\\'")
                q=f"'{root}' in parents and trashed=false and mimeType='{FOLDER_MIME}' and name='{safe}'"
                r=self._files_list(q,10)
                if not r: raise RuntimeError(f"Sibling folder missing or not shared: {name}")
                return r[0]["id"]
            return {"root":root,"ready":find("01_READY"),"posted":find("02_POSTED")}

        # Fallback when Drive omits parents on a shared My Drive folder.
        root=self._find_visible_folder("JUDM_MARKETING")["id"]
        ready=self._find_visible_folder("01_READY")["id"]
        posted=self._find_visible_folder("02_POSTED")["id"]
        return {"root":root,"ready":ready,"posted":posted}

    def _list(self,folder_id:str,limit=20):
        files,_=self.candidate_files(folder_id,max(limit,50))
        return files[:limit]

    def list_new(self,inbox_id:str,limit=20):
        return [f for f in self._list(inbox_id,limit) if (f.get("appProperties") or {}).get("judm_state") not in {"ready","posting","posted"}]

    def list_ready(self,inbox_id:str,ready_id:str,limit=20):
        out=[]; seen=set()
        for folder in (ready_id,inbox_id):
            for f in self._list(folder,limit):
                if f["id"] in seen: continue
                props=f.get("appProperties") or {}
                if folder==ready_id or props.get("judm_state") in {"ready","posting"}:
                    out.append(f); seen.add(f["id"])
        out.sort(key=lambda x:x.get("createdTime", "")); return out[:limit]

    def download(self,file_or_id:dict|str,target:str|Path):
        target=Path(target); target.parent.mkdir(parents=True,exist_ok=True)
        f=file_or_id if isinstance(file_or_id,dict) else self.get(file_or_id)
        file_id,_,resource_key=self._target_info(f)
        req=self.api.files().get_media(fileId=file_id,supportsAllDrives=True)
        if resource_key:
            req.headers["X-Goog-Drive-Resource-Keys"]=f"{file_id}/{resource_key}"
        with target.open("wb") as fh:
            dl=MediaIoBaseDownload(fh,req,chunksize=8*1024*1024); done=False
            while not done: _,done=dl.next_chunk()
        return target

    def local_name(self,f:dict)->str:
        name=_clean_name(f.get("name") or f.get("id") or "source")
        if Path(name).suffix.lower() not in VIDEO_EXTS and self._looks_video(f):
            name += ".mp4"
        return name

    def set_props(self,file_id:str,**props):
        cur=self.get(file_id).get("appProperties") or {}
        clean=dict(cur)
        for k,v in props.items():
            if v is None: clean.pop(k,None)
            else: clean[k]=str(v)[:120]
        return self.api.files().update(fileId=file_id,body={"appProperties":clean},fields="id,appProperties",supportsAllDrives=True).execute()

    def get(self,file_id:str):
        return self.api.files().get(fileId=file_id,fields=FILE_FIELDS,supportsAllDrives=True).execute()

    def move(self,file_id:str,to_parent:str):
        cur=self.get(file_id); old=",".join(cur.get("parents") or [])
        kwargs={"fileId":file_id,"addParents":to_parent,"fields":"id,parents","supportsAllDrives":True}
        if old: kwargs["removeParents"]=old
        return self.api.files().update(**kwargs).execute()

    def read_state(self,root_id:str)->dict:
        q=f"'{root_id}' in parents and trashed=false and name='JUDM_AUTO_STATE.json'"
        files=self._files_list(q,1)
        if not files: return {}
        buf=io.BytesIO(); dl=MediaIoBaseDownload(buf,self.api.files().get_media(fileId=files[0]["id"],supportsAllDrives=True)); done=False
        while not done: _,done=dl.next_chunk()
        try: return json.loads(buf.getvalue().decode("utf-8"))
        except Exception: return {}

    def write_state(self,root_id:str,state:dict):
        q=f"'{root_id}' in parents and trashed=false and name='JUDM_AUTO_STATE.json'"
        files=self._files_list(q,1)
        raw=json.dumps(state,ensure_ascii=False,separators=(",",":")).encode("utf-8")
        media=MediaIoBaseUpload(io.BytesIO(raw),mimetype="application/json",resumable=False)
        if files:
            return self.api.files().update(fileId=files[0]["id"],media_body=media,fields="id",supportsAllDrives=True).execute()
        raise RuntimeError("JUDM_AUTO_STATE.json is missing in JUDM_MARKETING")

    def move_or_mark(self,file_id:str,to_parent:str,state:str):
        self.set_props(file_id,judm_state=state,judm_error="")
        try:
            self.move(file_id,to_parent); return True
        except HttpError:
            return False
