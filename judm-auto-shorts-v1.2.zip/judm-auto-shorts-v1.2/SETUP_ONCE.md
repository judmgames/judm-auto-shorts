# 1회 설정 체크리스트 — v1.2

## 0. 먼저
플랫폼 승인 전 아래 변수는 전부 `false` 유지:
- `YOUTUBE_ENABLED`
- `INSTAGRAM_ENABLED`
- `TIKTOK_ENABLED`

## 1. Google Drive
1. Google Cloud 프로젝트 `judm-auto-shorts`에서 Google Drive API 활성화.
2. 서비스 계정 생성 후 JSON 키 발급.
3. JSON 전체를 GitHub Secret `GOOGLE_SERVICE_ACCOUNT_JSON`에 저장.
4. `judmgames@gmail.com`의 `JUDM_MARKETING` 폴더를 서비스 계정 이메일에 **편집자**로 공유.
5. 제공된 `JUDM_AUTO_STATE.json` 파일을 `JUDM_MARKETING` 루트에 한 번 업로드. (서비스 계정은 My Drive에서 새 파일을 소유할 수 없으므로 이 파일을 미리 만들어 둡니다.)
6. GitHub Actions에서 `JUD.M Auto Shorts` → `Run workflow` → `preview` 실행.
7. 생성된 `judm-preview` artifact로 실제 영상 편집 검수.

## 2. YouTube — 감사 승인 후만
Secrets:
- `GOOGLE_CLIENT_ID`
- `GOOGLE_CLIENT_SECRET`
- `GOOGLE_REFRESH_TOKEN`

Variable:
- `YOUTUBE_ENABLED=true`

## 3. Instagram
Instagram Login + Professional 계정. 권한: `instagram_business_basic`, `instagram_business_content_publish`.

Secrets:
- `INSTAGRAM_USER_ID`
- `INSTAGRAM_ACCESS_TOKEN`
- `CLOUDINARY_CLOUD_NAME`
- `CLOUDINARY_API_KEY`
- `CLOUDINARY_API_SECRET`

Variable:
- `INSTAGRAM_API_VERSION` (앱에서 사용 가능한 현재 Graph API 버전)
- 승인/실게시 검증 후 `INSTAGRAM_ENABLED=true`

## 4. TikTok — Accounts API 승인 후만
대상 TikTok은 Business Account. TikTok API for Business의 Accounts API 권한 필요:
`TikTok Accounts > Account Post Content > Video Publish`

Secrets:
- `TIKTOK_CLIENT_ID`
- `TIKTOK_CLIENT_SECRET`
- `TIKTOK_REFRESH_TOKEN`
- Cloudinary 3개 Secret은 Instagram과 공용

초기 `TIKTOK_REFRESH_TOKEN`만 GitHub Secret에 넣으면 이후 회전된 refresh token은 Drive의 `JUDM_AUTO_STATE.json`에 저장됩니다.

Variable:
- 승인/실게시 검증 후 `TIKTOK_ENABLED=true`

## 5. 장기 운영
월 1회 token-maintenance workflow가 Instagram long-lived token을 갱신하고 `.automation-heartbeat`를 commit하여 public repo의 60일 무활동 schedule 자동중지를 방지합니다.
